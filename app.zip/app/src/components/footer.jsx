import './footer.css';

function Footer() {
  return (
    <div className="footer">
      <p>Footer</p>
    </div>
  );
}

export default Footer;
